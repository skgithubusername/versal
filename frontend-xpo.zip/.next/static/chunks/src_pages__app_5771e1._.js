(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_pages__app_5771e1._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_pages__app_5771e1._.js",
  "chunks": [
    "static/chunks/node_modules_next_f80f03._.js",
    "static/chunks/node_modules_react-dom_82bb97._.js",
    "static/chunks/node_modules_react-icons_fa6_index_mjs_991a21._.js",
    "static/chunks/node_modules_react-icons_io_index_mjs_0372f8._.js",
    "static/chunks/node_modules_react-icons_lib_75a63d._.js",
    "static/chunks/node_modules_framer-motion_dist_es_30a232._.js",
    "static/chunks/node_modules_7cc175._.js",
    "static/chunks/[root of the server]__44b2c1._.js",
    "static/chunks/src_styles_globals_473809.css"
  ],
  "source": "entry"
});
