__turbopack_load_page_chunks__("/about", [
  "static/chunks/node_modules_next_f80f03._.js",
  "static/chunks/node_modules_react-dom_82bb97._.js",
  "static/chunks/node_modules_1b7400._.js",
  "static/chunks/[root of the server]__e5f2d1._.js",
  "static/chunks/src_pages_about_5771e1._.js",
  "static/chunks/src_pages_about_a61cac._.js"
])
