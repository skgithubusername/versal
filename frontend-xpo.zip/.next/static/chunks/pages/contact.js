__turbopack_load_page_chunks__("/contact", [
  "static/chunks/node_modules_next_f80f03._.js",
  "static/chunks/node_modules_react-dom_82bb97._.js",
  "static/chunks/node_modules_1b7400._.js",
  "static/chunks/[root of the server]__69d28d._.js",
  "static/chunks/src_pages_contact_5771e1._.js",
  "static/chunks/src_pages_contact_a1b2ea._.js"
])
