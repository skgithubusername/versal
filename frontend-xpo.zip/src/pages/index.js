// import Headers from "@/components/Header";
import PartyPlanning from "@/components/PartyPlanning";
import PartyPlanningPage from "@/components/PartyPlanningPage";
import PartyPlanningPage2 from "@/components/PartyPlanningPage2";

export default function Home() {
  return (
    <div className="  min-h-full  bg-white">
      {/* <Headers/> */}
      <PartyPlanning/>
      <PartyPlanningPage/>
      <PartyPlanningPage2/>
    </div>
  );
}
